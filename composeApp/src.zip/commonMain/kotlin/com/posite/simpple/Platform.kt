package com.posite.simpple

interface Platform {
    val name: String
}

expect fun getPlatform(): Platform